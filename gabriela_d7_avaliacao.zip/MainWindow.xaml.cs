﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace gabriela_d7_avaliacao
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Acessar(object sender, RoutedEventArgs e)
        {
            var UserEmail = Email.Text;
            var UserPassword = Senha.Password;

            using (DataContext context = new DataContext())
            {
                bool exists = context.Users.Any(user => user.Email == UserEmail && user.Password == UserPassword);
                
                if (exists)
                {
                    Info info = new Info();
                    info.Message("Usuário autenticado!");
                    info.Show();
                }
                else
                {
                    Info info = new Info();
                    info.Message("Credenciais inválidas!");
                    info.Show();
                }
            }
        }
    }
}
