﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gabriela_d7_avaliacao
{
    public  class DataContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuider)
        {
            optionsBuider.UseSqlite("Data source = banco.db");
        }

        public DbSet<User> Users { get; set; }
    }
}
